# DinoLoot v2.0

Add configurable loot drops to wild dino corpses on death.

## Features

- **Pattern-based matching**: Match dinos by partial blueprint name (e.g., `Alpha_` matches all alphas)
- **Loot pools**: Define multiple pools per dino with separate drop counts
- **Random quantities**: Set MinQuantity/MaxQuantity for randomized item amounts
- **Quality ranges**: Set MinQuality/MaxQuality for randomized item quality
- **Blueprint drops**: Configurable chance to drop as blueprint instead of item
- **Player notification**: Optional chat message when loot is acquired
- **Tamed dinos excluded**: Only wild dino kills trigger loot drops

## Installation

1. Copy `DinoLoot.dll` to `ArkApi/Plugins/DinoLoot/`
2. Copy `config.json` to `ArkApi/Plugins/DinoLoot/`
3. Edit config.json with your loot definitions
4. Restart server to load the plugin

## Configuration

### Settings

```json
"Settings": {
  "ChatPrefix": "DinoLoot",
  "MessageOnDrop": true
}
```

- `ChatPrefix`: Prefix shown in chat notifications
- `MessageOnDrop`: Show chat message when loot is acquired

### DinoLoot Definitions

Each dino pattern can have multiple loot pools:

```json
"DinoLoot": {
  "Rex_Character_BP": {
    "Pools": [
      {
        "Name": "RexLoot",
        "DropCount": 2,
        "Items": [
          {
            "Blueprint": "Blueprint'/Game/PrimalEarth/CoreBlueprints/Resources/PrimalItemResource_Hide'",
            "MinQuantity": 30,
            "MaxQuantity": 60,
            "MinQuality": 1.0,
            "MaxQuality": 1.0,
            "BlueprintChance": 0.0
          }
        ]
      }
    ]
  }
}
```

### Item Fields

| Field | Description |
|-------|-------------|
| `Blueprint` | Full blueprint path to the item |
| `MinQuantity` | Minimum quantity to drop |
| `MaxQuantity` | Maximum quantity to drop (random between min-max) |
| `MinQuality` | Minimum item quality (1.0 = primitive) |
| `MaxQuality` | Maximum item quality (random between min-max) |
| `BlueprintChance` | Chance (0.0-1.0) to drop as blueprint instead of item |

### Pool Fields

| Field | Description |
|-------|-------------|
| `Name` | Pool name (for logging) |
| `DropCount` | Number of items to randomly select from this pool |
| `Items` | Array of possible items in this pool |

### Pattern Matching

Dino patterns use partial matching:
- `Rex_Character_BP` - Matches wild Rex
- `Alpha_` - Matches all alpha dinos
- `Boss_` - Matches all boss creatures
- `Apex_` - Matches apex predators

## Console Commands

- `DinoLoot.Reload` - Reload configuration (admin only)
- `DinoLoot.List` - Show loaded dino definitions (admin only)

## License

**Free Mode**: 2 dino definitions (first 2 in config)

**Licensed**: Unlimited dino definitions

### Getting a License

1. Purchase a license at https://ko-fi.com/s/84cee00e04
2. Join our Discord: discord.gg/qsbhxDEUfw
3. Use the `/claim` command in the #license-claims channel with your Ko-fi email
4. You will receive a license key in format `XXXX-XXXX-XXXX-XXXX`
5. Add your key to config.json:

```json
"LicenseKey": "YOUR-LICENSE-KEY-HERE"
```

6. Restart the server or use `DinoLoot.Reload` to activate

### License Details

- **One-time purchase**: Annual license (365 days)
- **Per-machine**: License is tied to your server's hardware ID
- **Unlimited servers**: Run on as many servers as you want on the same machine
- **3 transfers included**: Move to a new machine up to 3 times

### Support

- Discord: discord.gg/qsbhxDEUfw
- Issues: Contact via Ko-fi or Discord
