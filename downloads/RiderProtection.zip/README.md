# RiderProtection

Protect players from damage while mounted. If riding a matching dino, rider takes no damage.

## Installation

1. Copy the `RiderProtection` folder to your server's `ArkApi/Plugins/` directory
2. Edit `config.json` to set protected mount patterns
3. Restart the server or use `plugins.load RiderProtection`

## Configuration

```json
{
  "ProtectedMounts": ["_C"],
  "Debug": false
}
```

### Config Options

| Option | Description |
|--------|-------------|
| `ProtectedMounts` | Array of dino class patterns that grant rider protection |
| `Debug` | Log blocked damage to ArkApi log |

### Pattern Matching

Patterns use **substring matching** (case-sensitive):

| Pattern | Effect |
|---------|--------|
| `_C` | All dinos (catch-all) |
| `Rex` | Rex, BionicRex, TekRex, etc. |
| `Berserk` | All Berserk dinos |
| `Prime` | All Prime dinos |

### Examples

**Protect on all mounts:**
```json
{
  "ProtectedMounts": ["_C"],
  "Debug": false
}
```

**Protect only on specific tiers:**
```json
{
  "ProtectedMounts": ["Berserk", "Prime", "Toxic"],
  "Debug": false
}
```

## Console Commands

| Command | Description |
|---------|-------------|
| `RiderProtection.Reload` | Reload config.json without restart |

## Notes

- Only affects **player characters** - dinos take damage normally
- Protection only applies while **actively mounted**
- Binary protection: either full protection or none

## Author

RokiArkNet
