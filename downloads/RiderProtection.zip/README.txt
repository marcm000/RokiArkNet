RiderProtection Plugin v1.0
===========================

Protect players from damage while mounted. Pattern matching determines which
dino classes grant rider protection.


INSTALLATION
------------
1. Copy the RiderProtection folder to:
   ShooterGame/Binaries/Win64/ArkApi/Plugins/

2. Edit config.json to set protected mount patterns

3. Restart server or use: plugins.load RiderProtection


ADMIN COMMANDS (Console)
------------------------
RiderProtection.Reload     - Reload config


CONFIG FORMAT
-------------
{
  "ProtectedMounts": ["_C"],
  "Debug": false
}

Options:
- ProtectedMounts: Array of dino class patterns that grant rider protection
- Debug: Log blocked damage to ArkApi log


PATTERN MATCHING
----------------
Patterns use substring matching (case-sensitive):

  _C        All dinos (catch-all)
  Rex       Rex, BionicRex, TekRex, etc.
  Tek       All Tek dinos


EXAMPLES
--------
Protect on all mounts:

{
  "ProtectedMounts": ["_C"],
  "Debug": false
}


Protect only on specific dino types:

{
  "ProtectedMounts": ["Rex", "Giga", "Wyvern"],
  "Debug": false
}


NOTES
-----
- Only affects player characters - dinos take damage normally
- Protection only applies while actively mounted
- Binary protection: either full protection or none


SUPPORT
-------
discord.gg/qsbhxDEUfw
