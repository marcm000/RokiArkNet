ItemExchange Plugin v1.1
========================

Item-for-item exchange via chat commands. No mod dependencies - works on all
platforms including console players.


INSTALLATION
------------
1. Copy the ItemExchange folder to:
   ShooterGame/Binaries/Win64/ArkApi/Plugins/

2. Edit config.json to define your exchanges

3. Restart server or use: ItemExchange.Reload


PLAYER COMMANDS
---------------
/ex                     - List available exchanges
/ex <name>              - Execute an exchange
/ex <name> <qty>        - Execute multiple times (e.g., /ex metal_to_ingot 10)


ADMIN COMMANDS (Console)
------------------------
ItemExchange.Reload     - Reload config
ItemExchange.List       - List all exchanges
ItemExchange.Add <name> <give:qty> <receive:qty>  - Add exchange (auto-saves)
ItemExchange.Remove <name>                        - Remove exchange (auto-saves)


CONFIG FORMAT
-------------
{
  "Settings": {
    "ChatPrefix": "Exchange",      // Chat message prefix
    "AllowMultiplier": true,       // Allow /ex name 10
    "MaxMultiplier": 100           // Max multiplier
  },
  "Exchanges": {
    "recipe_name": {
      "Description": "Shown to players",
      "Give": {
        "ItemClassName": quantity      // Partial match supported
      },
      "Receive": {
        "Blueprint'/Game/...'": quantity   // Full blueprint path required
      }
    }
  }
}

NOTES:
- "Give" items use partial class name matching (e.g., "PrimalItemResource_Metal")
- "Receive" items require full Blueprint path for GiveSlotItem
- Multiple Give/Receive items supported per exchange


MULTI-ITEM PACKS
----------------
Exchange multiple items for multiple items. Great for starter kits, trade packs,
or bulk conversions.

Example - Trade 5 ingots for a full tool set:

"starter_tools": {
  "Description": "5 Metal Ingots -> Pick, Hatchet, Pike",
  "Give": {
    "PrimalItemResource_MetalIngot": 5
  },
  "Receive": {
    "Blueprint'/Game/PrimalEarth/CoreBlueprints/Weapons/PrimalItem_WeaponMetalPick.PrimalItem_WeaponMetalPick'": 1,
    "Blueprint'/Game/PrimalEarth/CoreBlueprints/Weapons/PrimalItem_WeaponMetalHatchet.PrimalItem_WeaponMetalHatchet'": 1,
    "Blueprint'/Game/PrimalEarth/CoreBlueprints/Weapons/PrimalItem_WeaponPike.PrimalItem_WeaponPike'": 1
  }
}

Example - Require multiple items to give:

"advanced_kit": {
  "Description": "10 Ingots + 5 Hide -> Armor Set",
  "Give": {
    "PrimalItemResource_MetalIngot": 10,
    "PrimalItemResource_Hide": 5
  },
  "Receive": {
    "Blueprint'/Game/.../PrimalItemArmor_MetalChest.PrimalItemArmor_MetalChest'": 1,
    "Blueprint'/Game/.../PrimalItemArmor_MetalPants.PrimalItemArmor_MetalPants'": 1
  }
}


ARKSHOPUI INTEGRATION
---------------------
Add to ArkShop config.json under "Kits":

"exchange_metal": {
  "DefaultAmount": 999999,
  "Price": 0,
  "Description": "Trade Metal for Ingots",
  "Commands": [
    {
      "Command": "DoExchange {eosid} metal_to_ingot",
      "DisplayAs": "Exchange Metal for Ingots"
    }
  ]
}

IMPORTANT: Use {eosid} placeholder - ArkShop replaces it with player's EOS ID.

Players access via Packs tab in ArkShopUI.


RCON INTEGRATION
----------------
ItemExchange.Do <EOSID> <RecipeName>

Example: ItemExchange.Do 00012345678901234567890123456789 metal_to_ingot


SUPPORT
-------
discord.gg/qsbhxDEUfw
