# DinoLevelOverride

Override wild dino levels based on class name pattern matching. Set exact levels or random level ranges for specific dino types.

## Installation

1. Copy the `DinoLevelOverride` folder to your server's `ArkApi/Plugins/` directory
2. Edit `config.json` to set your level overrides
3. Restart the server or use `plugins.load DinoLevelOverride`

## Configuration

Edit `config.json` in the plugin folder:

```json
{
  "LevelOverrides": {
    "Rex": { "min": 100, "max": 150 },
    "Raptor": { "level": 50 },
    "Berserk": { "level": 500 },
    "ElementalLoot": { "level": 1000 }
  },
  "Debug": false
}
```

### Config Options

| Option | Description |
|--------|-------------|
| `LevelOverrides` | Map of patterns to level settings |
| `Debug` | Log all level changes to ArkApi log |
| `DifficultyStep` | (Optional) Manual level step override. Omit to auto-detect from OverrideOfficialDifficulty. |

### Level Override Options

**Exact Level:**
```json
"PatternName": { "level": 100 }
```
Spawns at exactly level 100, ignoring difficulty settings.

**Random Range:**
```json
"PatternName": { "min": 50, "max": 150 }
```
Spawns at a random level between 50-150, honoring OverrideOfficialDifficulty.

With OverrideOfficialDifficulty=10, range 50-150 produces: 50, 60, 70... 140, 150

### Difficulty Auto-Detection

The plugin automatically reads your server's `OverrideOfficialDifficulty` setting and applies it to level ranges. No manual configuration needed.

To manually override, add `"DifficultyStep": 5` to your config.

### Pattern Matching

Patterns use **substring matching** (case-sensitive):

| Pattern | Matches |
|---------|---------|
| `Rex` | `Rex_Character_BP_C`, `BionicRex_Character_BP_C` |
| `Berserk` | `BerserkRaptor_Character_BP_S_C`, `Dino_Character_BP_Berserk_C` |
| `_Toxic_` | `Defender_Character_BP_Toxic_S_C` (more specific) |
| `ElementalLoot` | `ElementalLoot_Character_BP_C` |

**Tip:** Use `DinoLevelOverride.Identify` command to discover exact class names for your dinos.

## Console Commands

| Command | Description |
|---------|-------------|
| `DinoLevelOverride.Reload` | Reload config.json without restart |
| `DinoLevelOverride.Identify [N]` | Log next N wild dino spawns to ArkApi log (default: 5) |

## Finding Dino Class Names

1. Run `DinoLevelOverride.Identify 20` in console
2. Do a `destroywilddinos` or wait for new spawns
3. Check ArkApi log for `[IDENTIFY]` entries showing class names

## Notes

- Only affects **new spawns** - existing dinos keep their levels
- Only affects **wild dinos** - tamed dinos are not modified
- Exact levels (`"level"`) spawn at that exact level regardless of difficulty
- Range levels (`"min"/"max"`) auto-honor OverrideOfficialDifficulty
- Changes apply immediately after `DinoLevelOverride.Reload`

## Version History

- **v1.1** - Auto-detect OverrideOfficialDifficulty, cleaned up code
- **v1.0** - Initial release

## Author

Rokitur
